1. put "php_win32service.dll" under "c:\xampp\php\ext"
2. open "php.ini" under "c:\xampp\php"
3. add this sentence "extension=php_win32service.dll" in.
4. restart apache service, verify it starts successfully.
5. done.