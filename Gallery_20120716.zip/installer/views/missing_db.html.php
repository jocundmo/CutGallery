<?php defined("SYSPATH") or die("No direct script access.") ?>
<h1> Can't find that database! </h1>
<p class="error">
  We were able to connect to your MySQL server, yay!  But the database
  name you gave us doesn't exist and we don't have permissions to
  create it for you.  Please create the database manually, then go
  back and try again.
</p>

<p>
  If you're having trouble creating the database, please contact your
  web host or system administrator for assistance.
</p>
