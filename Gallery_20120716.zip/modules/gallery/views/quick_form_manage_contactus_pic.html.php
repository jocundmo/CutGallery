<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div id="manage_contactus_pic_helper">
    <ul>
        <li>
            <?= t("请使用ftp服务")?>
        </li>
        <li><?= t("您可以打开您的资源管理器并在地址栏键入，或者使用ftp客户端访问如下")?></li>
        <li><?= t("请输入如下地址：ftp://www.ilovesmile.hk/contactuspic")?></li>
        <li><?= t("按提示输入ftp账号和密码（如有不知请咨询管理员）")?></li>
        <li><?= t("拖入您需要更换的图片") ?></li>
        <li><?= t("图片格式为“582*392”") ?></li>
        <li><?= t("图片名为\t“contactus1.jpg”，“contactus2.jpg”，\t“contactus3.jpg”，“contactus4.jpg”") ?></li>
        <li><?= t("单张建议大小不要超过100k") ?></li>
        <li><?= t("稍等片刻刷新页面") ?></li>
    </ul>
<?= $form ?>
</div>