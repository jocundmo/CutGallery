<?php defined("SYSPATH") or die("No direct script access.") ?>
<div id="g-error">
  <h1>
    <?= t("Dang...  Something went wrong!") ?>
  </h1>
  <h2>
    <?= t("We tried really hard, but it's broken.") ?>
  </h2>
  <p>
    <?= t("Talk to your Gallery administrator for help fixing this!") ?>
  </p>
</div>